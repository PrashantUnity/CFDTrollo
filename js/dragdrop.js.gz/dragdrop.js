console.log('🚀 Loading dragDrop.js with SortableJS...');

// Simple SortableJS implementation
window.dragDrop = {
    // State
    dotNetReference: null,
    sortableInstances: new Map(),

    // Initialize
    init: function(dotNetReference) {
        console.log('✅ Initializing dragDrop with SortableJS');
        this.dotNetReference = dotNetReference;
        this._injectStyles();
    },

    // Enable dragging on a list (for cards)
    enableCardDragging: function(listElement, listId) {
        console.log('🔧 Enabling card dragging for list:', listId);
        
        if (!listElement) {
            console.error('❌ List element is null');
            return;
        }

        // Create Sortable instance for cards
        const sortable = Sortable.create(listElement, {
            group: 'cards',
            animation: 150,
            ghostClass: 'sortable-ghost',
            chosenClass: 'sortable-chosen',
            dragClass: 'sortable-drag',
            handle: '.card-drag-handle',
            forceFallback: false,
            fallbackOnBody: true,
            swapThreshold: 0.65,
            invertSwap: false,
            direction: 'vertical',
            preventOnFilter: true,
            filter: '.no-drag, button, input, textarea, select, a',
            onStart: (evt) => {
                console.log('🚀 Card drag start:', evt.item.dataset.cardId);
                // Prevent text selection during drag
                document.body.style.userSelect = 'none';
                // Add a class to prevent other interactions
                evt.item.classList.add('dragging');
            },
            onEnd: (evt) => {
                console.log('🏁 Card drag end:', {
                    item: evt.item.dataset.cardId,
                    from: evt.from.dataset.listId,
                    to: evt.to.dataset.listId,
                    newIndex: evt.newIndex,
                    oldIndex: evt.oldIndex
                });

                // Restore text selection
                document.body.style.userSelect = '';
                // Remove dragging class
                evt.item.classList.remove('dragging');

                // Call C# method to handle the drop
                if (evt.from !== evt.to) {
                    // Moved to different list
                    this.dotNetReference.invokeMethodAsync('HandleCardMove', 
                        evt.item.dataset.cardId,
                        evt.from.dataset.listId,
                        evt.to.dataset.listId,
                        evt.newIndex);
                } else {
                    // Reordered within same list
                    this.dotNetReference.invokeMethodAsync('HandleCardReorder', 
                        evt.item.dataset.cardId,
                        evt.from.dataset.listId,
                        evt.oldIndex,
                        evt.newIndex);
                }
            }
        });

        this.sortableInstances.set(listId, sortable);
        console.log('✅ Card dragging enabled for list:', listId);
    },

    // Enable dragging on the board (for lists)
    enableListDragging: function(boardElement) {
        console.log('🔧 Enabling list dragging for board');
        
        if (!boardElement) {
            console.error('❌ Board element is null');
            return;
        }

        // Create Sortable instance for lists
        const sortable = Sortable.create(boardElement, {
            group: 'lists',
            animation: 150,
            ghostClass: 'sortable-ghost',
            chosenClass: 'sortable-chosen',
            dragClass: 'sortable-drag',
            handle: '.list-drag-handle',
            forceFallback: false,
            fallbackOnBody: true,
            swapThreshold: 0.65,
            invertSwap: false,
            direction: 'horizontal',
            preventOnFilter: true,
            filter: '.no-drag, button, input, textarea, select, a',
            onStart: (evt) => {
                console.log('🚀 List drag start:', evt.item.dataset.listId);
                // Prevent text selection during drag
                document.body.style.userSelect = 'none';
                // Add a class to prevent other interactions
                evt.item.classList.add('dragging');
            },
            onEnd: (evt) => {
                console.log('🏁 List drag end:', {
                    item: evt.item.dataset.listId,
                    newIndex: evt.newIndex,
                    oldIndex: evt.oldIndex
                });

                // Restore text selection
                document.body.style.userSelect = '';
                // Remove dragging class
                evt.item.classList.remove('dragging');

                // Call C# method to handle the reorder
                this.dotNetReference.invokeMethodAsync('HandleListReorder', 
                    evt.item.dataset.listId,
                    evt.oldIndex,
                    evt.newIndex);
            }
        });

        this.sortableInstances.set('board', sortable);
        console.log('✅ List dragging enabled for board');
    },

    // Destroy a sortable instance
    destroy: function(elementId) {
        const instance = this.sortableInstances.get(elementId);
        if (instance) {
            instance.destroy();
            this.sortableInstances.delete(elementId);
            console.log('✅ Destroyed sortable instance:', elementId);
        }
    },

    // Destroy all sortable instances
    destroyAll: function() {
        this.sortableInstances.forEach((instance, id) => {
            instance.destroy();
            console.log('✅ Destroyed sortable instance:', id);
        });
        this.sortableInstances.clear();
    },

    // Inject CSS styles
    _injectStyles: function() {
        const style = document.createElement('style');
        style.textContent = `
            .sortable-ghost {
                opacity: 0.4;
                background: #f0f0f0;
                border: 2px dashed #ccc;
            }
            
            .sortable-chosen {
                transform: rotate(5deg);
                box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            }
            
            .sortable-drag {
                transform: rotate(5deg);
                box-shadow: 0 8px 16px rgba(0,0,0,0.3);
            }
            
            .card-drag-handle {
                cursor: grab;
                user-select: none;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
            }
            
            .card-drag-handle:active {
                cursor: grabbing;
            }
            
            .list-drag-handle {
                cursor: grab;
                user-select: none;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
            }
            
            .list-drag-handle:active {
                cursor: grabbing;
            }
            
            .dragging {
                pointer-events: none;
                user-select: none;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
            }
            
            .dragging * {
                pointer-events: none;
                user-select: none;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
            }
            
            /* Prevent text selection during drag operations */
            .sortable-container {
                user-select: none;
                -webkit-user-select: none;
                -moz-user-select: none;
                -ms-user-select: none;
            }
            
            /* Ensure buttons and interactive elements don't interfere with drag */
            .no-drag {
                pointer-events: auto;
                user-select: auto;
                -webkit-user-select: auto;
                -moz-user-select: auto;
                -ms-user-select: auto;
            }
        `;
        document.head.appendChild(style);
    }
};

console.log('✅ dragDrop.js with SortableJS loaded successfully!');